using UnityEngine;
using UnityEngine.SceneManagement; 

public class SceneController : MonoBehaviour
{
    public KeyCode restartKey;
    [SerializeField] private AudioSource audioSource;
    [SerializeField] private AudioClip soundEffect;
    public void Start()
    {
        restartKey = KeyCode.R;
    }
    public void ReloadScene()
    {

        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        


    }


    void Update()
    {
        if (Input.GetKeyDown(restartKey))
        {
            Debug.Log("Reload");
            ReloadScene();
        }
    }
    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            Debug.Log("collision detected");
            audioSource.PlayOneShot(soundEffect, 1.0f);
            ReloadScene();
        }
    }


}