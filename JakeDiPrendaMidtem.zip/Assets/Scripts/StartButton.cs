using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement; // Required for changing scenes

public class StartButton : MonoBehaviour
{
    // This function must be public so the button can see it
    private int doNothing = 1;
    public GameObject myPrefab;
    public void Start()
    {
        Vector2 spawnPosition = new Vector2(-5.4f, -0.44f);
        myPrefab = Instantiate(myPrefab, spawnPosition, Quaternion.identity);
    }
    public void MoveToScene(string sceneName)
    {
        Debug.Log("click");
        SceneManager.LoadScene(1);
    }
    public void Update()
    {
        doNothing = 1;
    }
}