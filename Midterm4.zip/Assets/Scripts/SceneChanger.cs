using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
public class SceneChanger : MonoBehaviour
{
    public KeyCode nextSceneKey;
    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            Debug.Log("collision detected");
            ChangeScene();
        }
    }

    void ChangeScene()
    {
        int currentSceneIndex = SceneManager.GetActiveScene().buildIndex;
        int nextSceneIndex = currentSceneIndex + 1;
        if (nextSceneIndex <= SceneManager.sceneCountInBuildSettings || nextSceneIndex <= SceneManager.sceneCountInBuildSettings)
        {
            SceneManager.LoadScene(nextSceneIndex);
        }
        else
        {
            Debug.Log("No more scenes!");
        }

        //SceneManager.LoadScene(1);
    }

    void Update()
    {
        if (Input.GetKeyDown(nextSceneKey))
        {
            ChangeScene();
        }
    }
}
