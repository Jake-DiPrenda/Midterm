using UnityEngine;
using UnityEngine.SceneManagement; // Required for changing scenes

public class StartButton : MonoBehaviour
{
    // This function must be public so the button can see it


    public void MoveToScene(string sceneName)
    {
        Debug.Log("click");
        SceneManager.LoadScene(1);
    }
}