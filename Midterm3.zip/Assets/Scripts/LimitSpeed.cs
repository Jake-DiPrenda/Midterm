using UnityEngine;

public class LimitSpeed : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public Rigidbody2D my_rb;
    public float maxSpeed;

    private void FixedUpdate()
    {
        if (my_rb.linearVelocity.magnitude > maxSpeed)
        {
            my_rb.linearVelocity = my_rb.linearVelocity.normalized * maxSpeed;
        }
    }
}
