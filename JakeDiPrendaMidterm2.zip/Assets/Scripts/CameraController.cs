using UnityEngine;

public class CameraController : MonoBehaviour
{
    //these are the variables assigned to the camera so it knows what to follow
    public GameObject Player;
    [SerializeField] private Transform player;
    [SerializeField] private float followTime = 0.4f;

    //This causes the camera to follow the player as they move
    void Update()
    {
        float cameraX = Mathf.Lerp(transform.position.x, player.position.x, Time.deltaTime / followTime);
        transform.position = new Vector3(Player.transform.position.x, Player.transform.position.y, transform.position.z);
    }
}
