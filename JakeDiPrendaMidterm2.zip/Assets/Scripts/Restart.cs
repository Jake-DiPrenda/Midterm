using UnityEngine;
using UnityEngine.SceneManagement; 

public class SceneController : MonoBehaviour
{
    //this class is for restarting the scene. Be it from hitting a spike or pressing r
    //this is to initalize a key in the start function
    public KeyCode restartKey;
    
    [SerializeField] private AudioSource audioSource;
    [SerializeField] private AudioClip soundEffect;
    public void Start()
    {
        restartKey = KeyCode.R;
    }
    public void ReloadScene()
    {
        //reloads current scene
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        


    }


    void Update()
    {
        if (Input.GetKeyDown(restartKey))
        {
            Debug.Log("Reload");
            ReloadScene();
        }
    }
    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            Debug.Log("collision detected");
            //this should play a sound when you hit a spike
            audioSource.PlayOneShot(soundEffect, 1.0f);
            ReloadScene();
        }
    }


}