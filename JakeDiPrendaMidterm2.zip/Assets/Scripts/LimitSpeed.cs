using UnityEngine;

public class LimitSpeed : MonoBehaviour
{
    //this class is meant to stop the player from going too fast
    public Rigidbody2D my_rb;
    public float maxSpeed;

    private void FixedUpdate()
    {
        if (my_rb.linearVelocity.magnitude > maxSpeed)
        {
            my_rb.linearVelocity = my_rb.linearVelocity.normalized * maxSpeed;
        }
    }
}
