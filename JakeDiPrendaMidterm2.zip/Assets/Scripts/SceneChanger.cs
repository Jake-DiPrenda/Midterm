using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
public class SceneChanger : MonoBehaviour
{
    //initialize a key in the hierarchy
    public KeyCode nextSceneKey;
    [SerializeField] private GameObject removeTarget;
    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            Debug.Log("collision detected");
            ChangeScene();
        }
    }

    void ChangeScene()
    {
        //takes the current scene index adds 1 to it, then loads the scene
        int currentSceneIndex = SceneManager.GetActiveScene().buildIndex;
        int nextSceneIndex = currentSceneIndex + 1;
        if (nextSceneIndex <= SceneManager.sceneCountInBuildSettings || nextSceneIndex <= SceneManager.sceneCountInBuildSettings)
        {
            SceneManager.LoadScene(nextSceneIndex);
        }
        else
        {
            Debug.Log("No more scenes!");
        }

        //SceneManager.LoadScene(1);
    }

    void Update()
    {
        //to force move to next scene
        if (Input.GetKeyDown(nextSceneKey))
        {
            removeTarget.SetActive(false);
            ChangeScene();
        }
    }
}
