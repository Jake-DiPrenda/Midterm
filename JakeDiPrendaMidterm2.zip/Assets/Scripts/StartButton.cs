using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement; // Required for changing scenes

public class StartButton : MonoBehaviour
{
    //this script is because the button needed to have a specific script for loading level 1
    private int doNothing = 1;
    public GameObject myPrefab;
    public void Start()
    {
        Vector2 spawnPosition = new Vector2(-5.4f, -0.44f);
        //instantiates the cube on the title screen
        myPrefab = Instantiate(myPrefab, spawnPosition, Quaternion.identity);
    }
    public void MoveToScene(string sceneName)
    {
        Debug.Log("click");
        SceneManager.LoadScene(1);
    }
    public void Update()
    {
        // I needed another update function
        doNothing = 1;
    }
}