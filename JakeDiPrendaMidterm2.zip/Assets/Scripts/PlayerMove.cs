using NUnit.Framework;
using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections;
using System.Runtime.CompilerServices;

[RequireComponent(typeof(Rigidbody2D))]
public class PlayerMove : MonoBehaviour
{
    //how fast the player can move and how high they can jump
    public float moveSpeed = 8f;
    public float jumpForce = 14f;
    //public bool isGrounded;
    //variables for the jump function. They are the radius around the player that checks whether they are touching
    //the ground or a wall. It also has the force at which it is launched when wall jumping
    public Transform groundCheck;
    public float groundCheckRadius = 0.2f;
    public float wallSlideSpeed = 2f;
    public float wallCheckDistance = 0.5f;
    public Vector2 wallJumpForce = new Vector2(10f, 14);
    public float wallJumpDuration = 0.2f;
    public LayerMask groundLayer;
    private bool isWallSliding;
    private bool isWallJumping;
    private float moveInput;
    private int facingDirection = 1;
    public GameObject Player;
    
    private  Rigidbody2D my_rb;

    private Collider2D myCollider2D;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private void Awake()
    {
        my_rb = GetComponent<Rigidbody2D>();
    }
    // I never got this code to work, probably because I put it in the start function instead of update
    // but I don't want to break it now. The intention was to give the player friction while grounded to they wouldn't
    // slide around as much.
    void Start() 
    {
        myCollider2D = GetComponent<Collider2D>();
        PhysicsMaterial2D newMaterial = new PhysicsMaterial2D();

        if (IsGrounded() == true)
        {

            newMaterial.friction = 1f;
        }
        else 
        { 
            newMaterial.friction = 0f;
        }
    }
    //this isn't used but I needed another update method
    void Update()
    {
        ReadInput();

    }
    // Update is called once per frame
    //where all the movement functions are located
    void FixedUpdate()
    {
        Move();
        WallSlide();
        
        
        if (Input.GetKey(KeyCode.D))
        {
            Debug.Log("The Right key is pressed.");

            my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);
            if (IsGrounded() == false)
            {
                //this is done to give the player more control while they are in the air
                my_rb.AddForce(Vector2.right * (moveSpeed*3), ForceMode2D.Impulse);
            }
        }
        if (Input.GetKey(KeyCode.A))
        {
            Debug.Log("The Left key is pressed.");

            my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);
            if (IsGrounded() == false)
            {
                my_rb.AddForce(Vector2.left * (moveSpeed * 3), ForceMode2D.Impulse);
            }
        }
        /*
        old jump function I never deleted
        if ((Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.Space)) && isGrounded)
        {
            Debug.Log("The Up key is pressed.");
            Jump();
        }
        */
        
    }
    //not used because there was no momentum
    private void ReadInput()
    {
        Keyboard kb = Keyboard.current;
        moveInput = 0;
        if (kb.dKey.isPressed)
        {
            moveInput = 1;
        }
        if (kb.aKey.isPressed)
        {
            moveInput = -1;
        }

        if (kb.spaceKey.wasPressedThisFrame) Jump();
        if (moveInput != 0f) facingDirection = (int)moveInput;
    }

    //checks to see if you're on the ground and if you are allows you to jump
    private void Jump()
    {
        if (IsGrounded())
        {
            my_rb.linearVelocityY = jumpForce;
        }
        else if (isWallSliding)
        {
            StartCoroutine(WallJump());
        }

    }
    // checks to see if you're on the ground
    private bool IsGrounded()
    {
        return Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundLayer);
    }
    //not used
    private void Move()
    {
        if (isWallJumping) return;
        //my_rb.linearVelocityX = moveInput * moveSpeed;
    }
    //checks to see if you're touching a wall to allow you to wall jump
    private bool IsTouchingWall()
    {
        Vector2 checkPos = (Vector2)transform.position + Vector2.right * facingDirection * wallCheckDistance;
        return Physics2D.OverlapCircle(checkPos, groundCheckRadius, groundLayer);
    }
    // lets you slide down walls instead of sticking to them
    private void WallSlide()
    {
        isWallSliding = IsTouchingWall() && !IsGrounded() && !isWallJumping;
        if (isWallSliding)
        {
            my_rb.linearVelocityY = Mathf.Max(my_rb.linearVelocityY, -wallSlideSpeed);
        }
    }
    // the code that lets you wall jump
    private IEnumerator WallJump()
    {
        isWallJumping = true;
        facingDirection = -facingDirection;
        my_rb.linearVelocity = new Vector2(facingDirection * wallJumpForce.x, wallJumpForce.y);

        yield return new WaitForSeconds(wallJumpDuration);

        isWallJumping = false;
    }
}
